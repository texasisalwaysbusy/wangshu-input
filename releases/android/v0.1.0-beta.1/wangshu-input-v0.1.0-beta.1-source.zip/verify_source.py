#!/usr/bin/env python3
"""Read-only SHA256 verification. Never changes, removes, repairs or uploads files."""
from pathlib import Path
import hashlib,json,sys
if len(sys.argv)!=4:raise SystemExit('Usage: verify_source.py MANIFEST SOURCE_DIRECTORY before|after|source_files')
manifest,source,key=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
expected=json.loads(manifest.read_text(encoding='utf-8'))[key]
missing=[];different=[]
for name,value in expected.items():
 rel=Path(name)
 if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe manifest path')
 target=source/rel
 if not target.is_file():missing.append(name);continue
 sha=value['sha256'] if isinstance(value,dict) else value
 if hashlib.sha256(target.read_bytes()).hexdigest()!=sha:different.append(name)
print(json.dumps({'listed_files':len(expected),'missing':missing,'different':different,'success':not missing and not different,'scope':'Listed source files only; unrelated or build-generated files are not deleted.'},ensure_ascii=False,indent=2))
raise SystemExit(1 if missing or different else 0)
